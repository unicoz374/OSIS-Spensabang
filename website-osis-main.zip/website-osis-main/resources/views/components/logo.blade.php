<a href="{{ route('home') }}" class="flex items-center space-x-3 rtl:space-x-reverse">
    <img src="{{ asset('img/logo_smkn2.png') }}" class="h-8 md:h-10" alt="Logo SMK Negeri 2">
    <img src="{{ asset('img/logo-osis.png') }}" class="h-8 md:h-10" alt="Logo OSIS">
</a>
